package com.ozika.ifto.animalquestions;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AcertouActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acertou);
    }
}